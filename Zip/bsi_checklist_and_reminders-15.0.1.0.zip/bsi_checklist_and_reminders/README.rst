=============================
Checklist & Reminders
=============================

This Module helps to get to know actual time of assigning task and get reminder.
into Odoo 15 Community Edition

Installation
============

To install this module, you need to: project, employees

Download the module and add it to your Odoo addons folder. Afterward, log on to
your Odoo server and go to the Apps menu. Trigger the debug mode and update the
list by clicking on the "Update Apps List" link. Now install the module by
clicking on the install button.

Upgrade
============

To upgrade this module, you need to:

Download the module and add it to your Odoo addons folder. Restart the server
and log on to your Odoo server. Select the Apps menu and upgrade the module by
clicking on the upgrade button.


Configuration
=============

whenever we will assign task to employees and give expected time then we will know that task's actual time.


Credits
=======

Contributors
------------

* Botspot Infoware Pvt. Ltd. <contact@botspotinfoware.com>


Author & Maintainer
-------------------

This module is maintained by the Botspot Infoware Pvt. Ltd.
