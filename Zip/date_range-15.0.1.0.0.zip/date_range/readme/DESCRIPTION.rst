This module lets you define global date ranges that can be used to filter
your values in tree views.

It also provides a mixin model for developers that extends the model's search
view so that date ranges can be search as any relational field.
