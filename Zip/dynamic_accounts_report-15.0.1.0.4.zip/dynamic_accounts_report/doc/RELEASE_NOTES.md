## Module <dynamic_accounts_report>

#### 02.09.2021
#### Version 15.0.1.0.0
#### ADD
- Initial commit for Odoo 15 dynamic financial reports



#### 20.12.2021
#### Version 15.0.1.0.1
#### UPDT
- Translation issue and Calendar format issue

#### 15.01.2022
#### Version 15.0.1.0.2
#### UPDT
- Arabic Translation added

#### 01.02.2022
#### Version 15.0.1.0.3
#### UPDT AND BUGFIX
- Multi-company and Translation Update and Bugfix

#### 16.04.2022
#### Version 15.0.1.0.4
#### UPDT AND BUGFIX
- Loading issue and orderby date