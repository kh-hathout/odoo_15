Added new mixin `generic.mixin.refresh.view` that could be used to trigger
refresh of web client views via python
