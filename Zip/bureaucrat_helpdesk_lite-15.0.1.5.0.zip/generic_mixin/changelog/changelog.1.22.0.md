Added new mixin `generic.mixin.uuid` that could be used to automatically
generate uuids for records in specific model
