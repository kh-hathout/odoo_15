Update form view of Request Type
