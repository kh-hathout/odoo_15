Added configuration option, that allows to select preferred view for requests: list or kanban.
Currently this works only for standard menu *Requests*
