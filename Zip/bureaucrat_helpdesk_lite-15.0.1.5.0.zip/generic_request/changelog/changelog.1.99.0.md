Add global setting that could be used to show/hide request statistics on kanban views of
request-related objects like Request Category, Request type, etc
