#### Version 1.13.11
Added the ability to include request and response texts to mail notifications.
