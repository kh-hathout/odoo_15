from . import (
    test_access_rights,
    test_tour,
    test_mail,
    test_upload_file,
)
