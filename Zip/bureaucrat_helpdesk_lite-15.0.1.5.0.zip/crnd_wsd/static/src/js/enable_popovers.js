$(document).ready(function () {
    "use strict";
    $('[data-toggle="popover"]').popover();
});
