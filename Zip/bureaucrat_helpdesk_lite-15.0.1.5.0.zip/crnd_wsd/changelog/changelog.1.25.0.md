Fix layout regression on *fill request data* page introduced in release 1.14.0 or 1.14.1
