Added a link to a request on the website to go to this request in the
internal interface for the allowed user group.
