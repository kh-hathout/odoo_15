Added options in settings to choose the redirect way after request created
